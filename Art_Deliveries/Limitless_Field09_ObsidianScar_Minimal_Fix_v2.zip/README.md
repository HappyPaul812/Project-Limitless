LIMITLESS Field09 Obsidian Scar v2 - source-based changes from official 8 PNG, 512x512 RGBA.
All 8 images are independent corrected candidates; originals, meta/GUID and AshPatch/Ground_Cracked_02 protected.
Ground2: toroidal top/bottom/left/right edge alignment in 36/50-pixel perimeter bands, while center preserved; per-texture seam mismatch 0.
Guide6: bright neutral perimeter guideline pixels removed, not merely v1 low-alpha.
QA BeforeAfter_Comparison.html displays ACTUAL official and new image URLs side by side, network required, not Unity screenshots. Unity visual art QA pending; do not replace original before approval.
