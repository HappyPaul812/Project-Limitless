# Changelog

## 0.3.0 — 2026-08-20

- Added Rain Field, a seamless diagonal weather loop with near/far depth bands
  and low mist.
- Added Leaf Gust, a lateral autumn-leaf one-shot for wind and movement cues.
- Added Landing Dust, a grounded bilateral burst for landings, dashes, and
  heavy contact.
- Expanded the pack to 19 effects, 38 sprite sheets, and 276 canonical frames.
- Replaced cumulative showcase growth with a roomy, release-scoped update GIF.

## 0.2.0 — 2026-08-16

- Renamed the public collection to PVFX Foundry while retaining the stable
  `pvfx.foundry-thirteen` machine ID for compatibility.
- Added Rift Portal, a seamless dimensional-gate loop.
- Added Venom Ward, a seamless persistent status-aura loop.
- Added Smoke Puff, a compact environmental and gameplay utility one-shot.
- Expanded the pack to 16 effects, 32 sprite sheets, and 232 canonical frames.
- Generalized the release scripts and preview montage for append-only weekly
  expansion.

## 0.1.0 — 2026-08-03

- First public PVFX Foundry release, originally named Foundry Thirteen.
- Added 13 original 96×96, 20 FPS one-shot effects.
- Added fixed five-column grid sheets for simple import.
- Added per-frame trimmed packed sheets with padding and edge extrusion.
- Added exact manifests, pack-level metadata, checksums, and provenance.
- Dedicated the rendered sheets and bundled metadata/documentation to CC0 1.0.
